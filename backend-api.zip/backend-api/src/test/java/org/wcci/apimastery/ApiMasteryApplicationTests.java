package org.wcci.apimastery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class ApiMasteryApplicationTests {
	@Test
	public void contextLoads() {
	}

}
