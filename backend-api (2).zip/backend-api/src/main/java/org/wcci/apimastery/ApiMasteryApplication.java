package org.wcci.apimastery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiMasteryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiMasteryApplication.class, args);
	}

}
